# The version of Ren'Py reported by the version control software.
vc_version = 1520
